﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InterfaceSE.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Who are we?";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Contact Departments";

            return View();
        }
        public ActionResult AccountSet()
        {
            ViewBag.Message = "Account Settings";

            return View();
        }
        public ActionResult Customize()
        {
            ViewBag.Message = "Customize Interface";

            return View();
        }
        public ActionResult FAQ()
        {
            ViewBag.Message = "FAQ";

            return View();
        }
        public ActionResult GoogleApi()
        {
            ViewBag.Message = "Google Api";

            return View();
        }
        public ActionResult HowToUse()
        {
            ViewBag.Message = "HTU";

            return View();
        }
    }
}