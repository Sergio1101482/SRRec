﻿
   
    var canv;
    var canv2;
    var button;
    var button1;
    var button2;
    var button3;
    var buttonB1;
    var buttonB2;
    var buttonB3;
    var buttonB4;
    var buttonB5;
    var buttonB6;
    var buttonB7;
    var buttonB8;
    
    function init() {
        
        

        canv2 = document.createElement('canvas');//bottom canvas used to display changing buttons
        canv2.id = 'main';
        canv2.style.backgroundColor = 'red';
        canv2.style.top = ((window.innerHeight / 8)-2)+"px";
        canv2.style.left = "0px";
        canv2.width = window.innerWidth;
        canv2.height = window.innerHeight / 16;
        canv2.style.position = "absolute";
        document.body.appendChild(canv2);

        canv = document.createElement('canvas');//top canvas used to display main control buttons
        canv.id = 'topcanvas';
        canv.style.backgroundColor = 'white';
        canv.style.top = "0px";
        canv.style.left = "0px";
        canv.width = window.innerWidth;
        canv.height = window.innerHeight / 8;
        canv.style.position = "absolute";
        document.body.appendChild(canv); // adds the canvas to the body element

      
        
        
        

        button = document.createElement("button");//buttons on top canvas
        button.id = 'SRrec';
        button.innerHTML = "Shopping Route Recomender";
        button.style.color = 'red';
        button.style.backgroundColor = 'white';
        button.style.top =window.innerHeight*1/64+"px";
        button.style.left = window.innerWidth * 1 / 4 + "px";
        button.style.width = window.innerWidth * 3 / 18 + "px";
        button.style.height = window.innerHeight * 6 / 64 + "px";
        button.style.border = "none";
        button.className = "btn1";
        button.style.position = "absolute";
        button.onclick = function () { click4(); }
        document.body.appendChild(button);

        button1 = document.createElement("button");
        button1.id = 'Aboutbtn';
        button1.innerHTML = "About Us";
        button1.style.color = 'red';
        button1.style.backgroundColor = 'white';
        button1.style.top = window.innerHeight * 1 / 64 + "px";
        button1.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 3 / 16 + "px";
        button1.style.width = window.innerWidth * 3 / 18 + "px";
        button1.style.height = window.innerHeight * 6 / 64 + "px";
        button1.style.border = "none";
        button1.className = "btn1";
        button1.style.position = "absolute";
        button1.onclick = function () { click1(); }
        document.body.appendChild(button1);

        button2 = document.createElement("button");
        button2.id = 'helpbtn';
        button2.innerHTML = "Help";
        button2.style.color = 'red';
        button2.style.backgroundColor = 'white';
        button2.style.top = window.innerHeight * 1 / 64 + "px";
        button2.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 6 / 16 + "px";
        button2.style.width = window.innerWidth * 3 / 18 + "px";
        button2.style.height = window.innerHeight * 6 / 64 + "px";
        button2.style.border = "none";
        button2.className = "btn1";
        button2.style.position = "absolute";
        button2.onclick = function () { click2(); }
        document.body.appendChild(button2);

        button3 = document.createElement("button");
        button3.id = 'Settingbtn';
        button3.innerHTML = "Settings";
        button3.style.color = 'red';
        button3.style.backgroundColor = 'white';
        button3.style.top = window.innerHeight * 1 / 64 + "px";
        button3.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 9 / 16 + "px";
        button3.style.width = window.innerWidth * 3 / 18 + "px";
        button3.style.height = window.innerHeight * 6 / 64 + "px";
        button3.style.border = "none";
        button3.className = "btn1";
        button3.style.position = "absolute";
        button3.onclick = function () { click3(); }
        document.body.appendChild(button3);

        buttonB1 = document.createElement("button");//start of buttons on bottom canvas
        buttonB1.id = "SRrec1";
        buttonB1.innerHTML = "Shortest Path";
        buttonB1.style.color = 'white';
        buttonB1.style.backgroundColor = 'red';
        buttonB1.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20)/2) -2+ "px";
        buttonB1.style.left = window.innerWidth * 1 / 4 + "px";
        buttonB1.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB1.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB1.style.border = "none";
        buttonB1.className = "btn1";
        buttonB1.onclick = function () { window.location.href = "/Products/Index" };
        buttonB1.style.position = "absolute";
        document.body.appendChild(buttonB1);

        buttonB2 = document.createElement("button");
        buttonB2.id = "LowCst";
        buttonB2.innerHTML = "Lowest Cost";
        buttonB2.style.color = 'white';
        buttonB2.style.backgroundColor = 'red';
        buttonB2.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB2.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 3 / 16 + "px";
        buttonB2.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB2.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB2.style.border = "none";
        buttonB2.className = "btn1";
        buttonB2.onclick = function () { window.location.href = "/Home/Customize" };//change to lowest cost
        buttonB2.style.position = "absolute";
        document.body.appendChild(buttonB2);

        buttonB3 = document.createElement("button");
        buttonB3.id = "Desc";
        buttonB3.innerHTML = "Description";
        buttonB3.style.color = 'white';
        buttonB3.style.backgroundColor = 'deepskyblue';
        buttonB3.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB3.style.left = window.innerWidth * 1 / 4 + "px";
        buttonB3.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB3.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB3.style.border = "none";
        buttonB3.className = "btn2";
        buttonB3.onclick = function () { window.location.href = "/Home/About" };
        buttonB3.style.position = "absolute";
        document.body.appendChild(buttonB3);

        buttonB4 = document.createElement("button");
        buttonB4.id = "Contact";
        buttonB4.innerHTML = "Contact Us";
        buttonB4.style.color = 'white';
        buttonB4.style.backgroundColor = 'deepskyblue';
        buttonB4.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB4.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 3 / 16 + "px";
        buttonB4.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB4.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB4.style.border = "none";
        buttonB4.className = "btn2";
        buttonB4.onclick = function () { window.location.href = "/Home/Contact" };
        buttonB4.style.position = "absolute";
        document.body.appendChild(buttonB4);

        buttonB5 = document.createElement("button");
        buttonB5.id = "HTU";
        buttonB5.innerHTML = "How To Use";
        buttonB5.style.color = 'white';
        buttonB5.style.backgroundColor = 'lawngreen';
        buttonB5.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB5.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 3 / 16 + "px";
        buttonB5.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB5.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB5.style.border = "none";
        buttonB5.className = "btn3";
        buttonB5.onclick = function () { window.location.href = "/Home/HowToUse" };
        buttonB5.style.position = "absolute";
        document.body.appendChild(buttonB5);

        buttonB6 = document.createElement("button");
        buttonB6.id = "FAQ";
        buttonB6.innerHTML = "FAQ";
        buttonB6.style.color = 'white';
        buttonB6.style.backgroundColor = 'lawngreen';
        buttonB6.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB6.style.left = window.innerWidth * 1 / 4 + "px";
        buttonB6.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB6.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB6.style.border = "none";
        buttonB6.className = "btn3";
        buttonB6.onclick = function () { window.location.href = "/Home/FAQ" };
        buttonB6.style.position = "absolute";
        document.body.appendChild(buttonB6);

        buttonB7 = document.createElement("button");
        buttonB7.id = "Set1";
        buttonB7.innerHTML = "Customize";
        buttonB7.style.color = 'white';
        buttonB7.style.backgroundColor = 'gold';
        buttonB7.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB7.style.left = window.innerWidth * 1 / 4 + "px";
        buttonB7.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB7.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB7.style.border = "none";
        buttonB7.className = "btn4";
        buttonB7.onclick = function () { window.location.href = "/Home/Customize" };
        buttonB7.style.position = "absolute";
        document.body.appendChild(buttonB7);

        buttonB8 = document.createElement("button");
        buttonB8.id = "Set2";
        buttonB8.innerHTML = "Account settings";
        buttonB8.style.color = 'white';
        buttonB8.style.backgroundColor = 'gold';
        buttonB8.style.top = window.innerHeight * 1 / 8 + ((window.innerHeight * 1 / 16 - window.innerHeight * 1 / 20) / 2) - 2 + "px";
        buttonB8.style.left = window.innerWidth * 1 / 4 + window.innerWidth * 3 / 16 + "px";
        buttonB8.style.width = window.innerWidth * 3 / 18 + "px";
        buttonB8.style.height = window.innerHeight * 1 / 20 + "px";
        buttonB8.style.border = "none";
        buttonB8.className = "btn4";
        buttonB8.onclick = function () { window.location.href = "/Home/AccountSet" };
        buttonB8.style.position = "absolute";
        document.body.appendChild(buttonB8);


        hide();

        canv2.style.display = "initial";
        button.style.display = "initial";
        button1.style.display = "initial";
        button2.style.display = "initial";
        button3.style.display = "initial";
        //button4.style.display = "initial";
        buttonB1.style.display = "initial";
        buttonB2.style.display = "initial";
        var canvhldr = document.getElementById("canvasholder");//used to format the page so it fits in the remaining space
        canvhldr.style.position = "absolute";
        canvhldr.style.top = window.innerHeight / 16 + (window.innerHeight / 8) + "px";
        canvhldr.style.left = "10px";
        canvhldr.style.height = window.innerHeight - (window.innerHeight / 16 + (window.innerHeight / 8) + 50) + "px";
        canvhldr.style.width = window.innerWidth -50+ "px";

    }
    function hide() {//hides all elements so that different ones can be displayed
        //canv2.style.display = "none";
        buttonB1.style.display = "none";
        buttonB2.style.display = "none";
        buttonB3.style.display = "none";
        buttonB4.style.display = "none";
        buttonB5.style.display = "none";
        buttonB6.style.display = "none";
        buttonB7.style.display = "none";
        buttonB8.style.display = "none";
    }
    function click1() {//shows certain objects that pertain to the button that is clicked
        hide();
        canv2.style.backgroundColor = 'deepskyblue';
        button.className = "btn2";
        button1.className = "btn2";
        button2.className = "btn2";
        button3.className = "btn2";
        buttonB3.style.display = "initial";
        buttonB4.style.display = "initial";
        button.style.color = canv2.style.backgroundColor;
        button1.style.color = canv2.style.backgroundColor;
        button2.style.color = canv2.style.backgroundColor;
        button3.style.color = canv2.style.backgroundColor;
    }
    function click2() {
        hide();
        canv2.style.backgroundColor = 'lawngreen';
        button.className = "btn3";
        button1.className = "btn3";
        button2.className = "btn3";
        button3.className = "btn3";
        buttonB5.style.display = "initial";
        buttonB6.style.display = "initial";
        button.style.color = canv2.style.backgroundColor;
        button1.style.color = canv2.style.backgroundColor;
        button2.style.color = canv2.style.backgroundColor;
        button3.style.color = canv2.style.backgroundColor;
    }
    function click3() {
        hide();
        canv2.style.backgroundColor = 'gold';
        button.className = "btn4";
        button1.className = "btn4";
        button2.className = "btn4";
        button3.className = "btn4";
        buttonB7.style.display = "initial";
        buttonB8.style.display = "initial";
        button.style.color = canv2.style.backgroundColor;
        button1.style.color = canv2.style.backgroundColor;
        button2.style.color = canv2.style.backgroundColor;
        button3.style.color = canv2.style.backgroundColor;
    }
    function click4() {
        hide();
        canv2.style.backgroundColor = 'red';
        button.className = "btn1";
        button1.className = "btn1";
        button2.className = "btn1";
        button3.className = "btn1";
        buttonB1.style.display = "initial";
        buttonB2.style.display = "initial";
        button.style.color = canv2.style.backgroundColor;
        button1.style.color = canv2.style.backgroundColor;
        button2.style.color = canv2.style.backgroundColor;
        button3.style.color = canv2.style.backgroundColor;
    }
    window.onload = init;